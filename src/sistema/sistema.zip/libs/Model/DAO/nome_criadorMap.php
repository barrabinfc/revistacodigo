<?php
/** @package    Sistema::Model::DAO */

/** import supporting libraries */
require_once("verysimple/Phreeze/IDaoMap.php");
require_once("verysimple/Phreeze/IDaoMap2.php");

/**
 * nome_criadorMap is a static class with functions used to get FieldMap and KeyMap information that
 * is used by Phreeze to map the nome_criadorDAO to the creatorname datastore.
 *
 * WARNING: THIS IS AN AUTO-GENERATED FILE
 *
 * This file should generally not be edited by hand except in special circumstances.
 * You can override the default fetching strategies for KeyMaps in _config.php.
 * Leaving this file alone will allow easy re-generation of all DAOs in the event of schema changes
 *
 * @package Sistema::Model::DAO
 * @author ClassBuilder
 * @version 1.0
 */
class nome_criadorMap implements IDaoMap, IDaoMap2
{

	private static $KM;
	private static $FM;
	
	/**
	 * {@inheritdoc}
	 */
	public static function AddMap($property,FieldMap $map)
	{
		self::GetFieldMaps();
		self::$FM[$property] = $map;
	}
	
	/**
	 * {@inheritdoc}
	 */
	public static function SetFetchingStrategy($property,$loadType)
	{
		self::GetKeyMaps();
		self::$KM[$property]->LoadType = $loadType;
	}

	/**
	 * {@inheritdoc}
	 */
	public static function GetFieldMaps()
	{
		if (self::$FM == null)
		{
			self::$FM = Array();
			self::$FM["Idcreatorname"] = new FieldMap("Idcreatorname","creatorname","idcreatorname",true,FM_TYPE_INT,11,null,true);
			self::$FM["Creator"] = new FieldMap("Creator","creatorname","creator",false,FM_TYPE_INT,11,null,false);
			self::$FM["Naname"] = new FieldMap("Naname","creatorname","naname",false,FM_TYPE_VARCHAR,60,null,false);
			self::$FM["Type"] = new FieldMap("Type","creatorname","type",false,FM_TYPE_VARCHAR,60,null,false);
		}
		return self::$FM;
	}

	/**
	 * {@inheritdoc}
	 */
	public static function GetKeyMaps()
	{
		if (self::$KM == null)
		{
			self::$KM = Array();
		}
		return self::$KM;
	}

}

?>