	<!-- footer -->
	<div class="container">
		<hr>
		<footer>
			<p class="muted"><small>&copy; <?php echo date('Y'); ?> sistema</small></p>
		</footer>
	</div>
	</body>
</html>